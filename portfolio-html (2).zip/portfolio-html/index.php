<?php

require 'database.php';

// Kijkt of knop ingedrukt is -> of de request methode post is (optioneel), of de inputvelden gevuld is. Zo ja? Insert into database
if (isset($_POST['submit'])) {
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        if (trim($_POST['naam']) == "" && (trim($_POST['email']) == "") && (trim($_POST['onderwerp']) == "") && (trim($_POST['beschrijving']) == "")) {
            echo "Vul alle velden in";
        } else if (trim($_POST['naam']) == "") {
            echo "Vul een naam in";
        } else if (trim($_POST['email']) == "") {
            echo "Vul een emailadres in";
        } else if (trim($_POST['onderwerp']) == "") {
            echo "Vul een onderwerp in";
        } else if (trim($_POST['beschrijving']) == "") {
            echo "Vul een beschrijving";
        } else {
            $naam = $_POST['naam'];
            $email = $_POST['email'];
            $onderwerp = $_POST['onderwerp'];
            $beschrijving = $_POST['beschrijving'];

            $sql = "INSERT INTO berichten (naam, email, onderwerp, beschrijving)
    VALUES ('$naam', '$email', '$onderwerp', '$beschrijving')";


            if ($conn->query($sql) === TRUE) {
                header('Refresh: 0; url=portfolio-site.php');
            } else {
                echo 'Fail';
            }
            mysqli_close($conn); // Sluit de database verbinding
        }
    }
}
