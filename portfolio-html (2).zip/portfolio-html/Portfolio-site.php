<?php

require 'database.php';

//SQL SECTIE VOOR PROJECTEN
$sql_project = "SELECT * FROM projecten";

$result_project = mysqli_query($conn, $sql_project);

$alle_projecten = mysqli_fetch_all($result_project, MYSQLI_ASSOC);

//SQL SECTIE VOOR ERVARINGEN

$sql_ervaring = "SELECT * FROM ervaring";

$result_ervaring = mysqli_query($conn, $sql_ervaring);

$alle_ervaring = mysqli_fetch_all($result_ervaring, MYSQLI_ASSOC);

//SQL SECTIE VOOR HOBBY'S

$sql_hobby = "SELECT * FROM hobby";

$result_hobby = mysqli_query($conn, $sql_hobby);

$alle_hobby = mysqli_fetch_all($result_hobby, MYSQLI_ASSOC);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Portfolio</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/03aefebace.js%22%3E"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.11/typed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
</head>

<body>
    <div class="scroll-up-btn">
        <i class="fas fa-angle-up"></i>
    </div>
    <nav class="navbar">
        <div class="max-width">
            <div class="logo"><a href="#">Mert's <span>Portfolio.</span></a></div>
            <ul class="menu">
                <li><a href="#home" class="menu-btn">Home</a></li>
                <li><a href="#about" class="menu-btn">About</a></li>
                <li><a href="#hobbys" class="menu-btn">Hobby's</a></li>
                <li><a href="#skills" class="menu-btn">Skills</a></li>
                <li><a href="#projecten" class="menu-btn">Projecten</a></li>
                <li><a href="#contact" class="menu-btn">Contact</a></li>
            </ul>
            <div class="menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>
    <!-- home section start -->
    <section class="home" id="home">
        <div class="max-width">
            <div class="home-content">
                <div class="text-1">Hallo, mijn naam is</div>
                <div class="text-2">Mert Babur</div>
                <div class="text-3">En ik ben een <span class="typing"></span></div>
                <a href="#">Neem me aan</a>
            </div>
        </div>
    </section>
    <!-- about section start -->
    <section class="about" id="about">
        <div class="max-width">
            <h2 class="title">Over Mij</h2>
            <div class="about-content">
                <div class="column left">
                    <img src="../portfolio-html/Images/mertportfolio.jpg" alt="">
                </div>
                <div class="column right">
                    <div class="text">Ik ben Mert babur en ik ben een <span class="typing-2"></span></div>
                    <p>
                        Hallo en welkom bij mijn Portfolio. Mijn naam is Mert Babur,
                        ik ben 18 jaar oud en ben geboren in Haarlem, Nederland.
                        Ik heb 2 huisdieren, een kater genaamd Yugi 遊戯 en een poes genaamd Yui ゆい
                        beide Blauwe Russen.
                    </p>
                    <a href="cv.html">Ga naar CV</a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Mijn hobby's section start -->
    
    <section class="services" id="services">
        <div class="max-width">
            <h2 class="title">Mijn Hobby's</h2>
            <div class="serv-content">

            <?php foreach ($alle_hobby as $hobby){?>
                <div class="card">
                    <div class="box">
                        <i class="<?php echo $hobby['icon']?>"></i>
                        <div class="text"><?php echo $hobby['naam']?></div>
                        <p><?php echo $hobby['uitleg']?></p>
                    </div>
                </div>
            <?php }?>

            </div>
        </div>
    </section>

    <!-- skills section start -->

    <section class="skills" id="skills">
        <div class="max-width">
            <h2 class="title">Mijn Skills</h2>
            <div class="skills-content">
                <div class="column left">
                    <div class="text">Mijn Creatieve Skills & Ervaringen.</div>
                    <p>Door het jaar heen heb ik verschillende codeer talen gehad, hier zijn ze:</p><br>
                </div>

                <div class="column right">

                <?php foreach ($alle_ervaring as $ervaring) : ?>
                    <div class="bars">
                        <div class="info">
                            <span><?php echo $ervaring['naam']?></span>
                            <span><?php echo $ervaring['length']?>%</span>
                        </div>
                        <div class="line <?php echo $ervaring['naam']?>"></div>
                <?php endforeach;   ?>
                <?php foreach ($alle_ervaring as $ervaring) :?>
                        <style>
                            .ervaring-content .right .<?php echo $ervaring['naam'] ?>::before {
                                width: <?php echo $ervaring['length'];?>%; 
                            }
                        </style>
                <?php endforeach;  ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- PROJECTEN section start -->
    <section class="teams" id="teams">
        <div class="max-width">
            <h2 class="title">Gemaakte Projecten</h2>
            <div class="carousel owl-carousel">

                <?php foreach ($alle_projecten as $project) { ?>

                    <div class="card">
                        <div class="box">
                            <img src="Images\<?php echo $project['image'] ?>" alt="<?php echo $project['naam']?>">
                            <div class="text"><?php echo $project['naam'] ?></div>
                            <p><?php echo $project['beschrijving'] ?></p>
                        </div>
                    </div>

                <?php } ?>
            </div>
        </div>
    </section>

    <!-- contact section start -->

    <section class="contact" id="contact">
        <div class="max-width">
            <h2 class="title">Neem Contact Met Me Op</h2>
            <div class="contact-content">
                <div class="column left">
                    <div class="text">Kom In Aanraking</div>
                    <p>
                        Stuur een mail naar de onderstaande mail,
                        u zult binnen 5 werkdagen een spoedig antwoord
                        terug verwachten. Wij doen niet aan telefonisch bellen.
                    </p>

                    <div class="icons">
                        <div class="row">
                            <i class="fas fa-user"></i>
                            <div class="info">
                                <div class="head">Naam</div>
                                <div class="sub-title">Mert Babur</div>
                            </div>
                        </div>

                        <div class="row">
                            <i class="fas fa-map-marker-alt"></i>
                            <div class="info">
                                <div class="head">Address</div>
                                <div class="sub-title">Zijlweg 203, 2015 CK Haarlem, Nederland</div>
                            </div>
                        </div>

                        <div class="row">
                            <i class="fas fa-envelope"></i>
                            <div class="info">
                                <div class="head">Email</div>
                                <div class="sub-title">183227@novacollege.nl</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="column right">
                    <div class="text">Stuur Een Bericht</div>
                    <form action="index.php" method="post">
                        <div class="velden">

                            <div class="veld naam">
                                <input type="text" placeholder="Naam" name="naam" required>
                            </div>

                            <div class="field email">
                                <input type="email" placeholder="Email" name="email" required>
                            </div>

                        </div>

                        <div class="field">
                            <input type="text" placeholder="Onderwerp" name="onderwerp" required>
                        </div>

                        <div class="field textarea" name="uitleg">
                            <textarea cols="30" rows="10" placeholder="Bericht" name="beschrijving" required></textarea>
                        </div>

                        <div class="button-area">
                            <button name="submit" type="submit">Stuur Een Bericht</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- footer section start -->
    <footer>
        <span>Gemaakt door Mert Babur | <span class="far fa-copyright"></span> 2022 Alle rechten gereserveerd.</span>
    </footer>
    <script src="script.js"></script>
</body>

</html>